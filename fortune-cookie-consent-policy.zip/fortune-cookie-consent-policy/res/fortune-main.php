<?php

function fortune_admin_settings()
{
?>
<div class="wrap seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('fortune_option_group');
    do_settings_sections('fortune_option_group');
    $fortune_Main_Settings = get_option('fortune_Main_Settings', false);
    if (isset($fortune_Main_Settings['fortune_enabled'])) {
        $fortune_enabled = $fortune_Main_Settings['fortune_enabled'];
    } else {
        $fortune_enabled = 'off';
    }
    if (isset($fortune_Main_Settings['fortune_popup_once'])) {
        $fortune_popup_once = $fortune_Main_Settings['fortune_popup_once'];
    } else {
        $fortune_popup_once = '';
    }
    if (isset($fortune_Main_Settings['fortune_popup_style'])) {
        $fortune_popup_style = $fortune_Main_Settings['fortune_popup_style'];
    } else {
        $fortune_popup_style = 'fortune_panel_top';
    }
    if (isset($fortune_Main_Settings['fortune_message'])) {
        $fortune_message = $fortune_Main_Settings['fortune_message'];
    } else {
        $fortune_message = 'This site uses cookies to deliver its services. By using this site, you agree to its use of cookies.';
    }
    if (isset($fortune_Main_Settings['fortune_close_message'])) {
        $fortune_close_message = $fortune_Main_Settings['fortune_close_message'];
    } else {
        $fortune_close_message = 'Close';
    }
    if (isset($fortune_Main_Settings['fortune_more_info'])) {
        $fortune_more_info = $fortune_Main_Settings['fortune_more_info'];
    } else {
        $fortune_more_info = '';
    }
    if (isset($fortune_Main_Settings['fortune_more_link'])) {
        $fortune_more_link = $fortune_Main_Settings['fortune_more_link'];
    } else {
        $fortune_more_link = 'https://www.google.com/policies/technologies/cookies/';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background'])) {
        $fortune_popup_background = $fortune_Main_Settings['fortune_popup_background'];
    } else {
        $fortune_popup_background = '#aaaaaa';
    }
    if (isset($fortune_Main_Settings['fortune_popup_text_col'])) {
        $fortune_popup_text_col = $fortune_Main_Settings['fortune_popup_text_col'];
    } else {
        $fortune_popup_text_col = '#000000';
    }
    if (isset($fortune_Main_Settings['fortune_popup_links_col'])) {
        $fortune_popup_links_col = $fortune_Main_Settings['fortune_popup_links_col'];
    } else {
        $fortune_popup_links_col = '#0000ff';
    }
    if (isset($fortune_Main_Settings['fortune_button_background'])) {
        $fortune_button_background = $fortune_Main_Settings['fortune_button_background'];
    } else {
        $fortune_button_background = '#0000ff';
    }
    if (isset($fortune_Main_Settings['fortune_button_border'])) {
        $fortune_button_border = $fortune_Main_Settings['fortune_button_border'];
    } else {
        $fortune_button_border = '#0000ff';
    }
    if (isset($fortune_Main_Settings['fortune_more_link_text'])) {
        $fortune_more_link_text = $fortune_Main_Settings['fortune_more_link_text'];
    } else {
        $fortune_more_link_text = 'More Info';
    }
    if (isset($fortune_Main_Settings['fortune_panel_sticks'])) {
        $fortune_panel_sticks = $fortune_Main_Settings['fortune_panel_sticks'];
    } else {
        $fortune_panel_sticks = '';
    }
    if (isset($fortune_Main_Settings['fortune_auto_hide_time'])) {
        $fortune_auto_hide_time = $fortune_Main_Settings['fortune_auto_hide_time'];
    } else {
        $fortune_auto_hide_time = '5000';
    }
    if (isset($fortune_Main_Settings['fortune_border'])) {
        $fortune_border = $fortune_Main_Settings['fortune_border'];
    } else {
        $fortune_border = '';
    }
    if (isset($fortune_Main_Settings['fortune_border_color'])) {
        $fortune_border_color = $fortune_Main_Settings['fortune_border_color'];
    } else {
        $fortune_border_color = '#ff0000';
    }
    if (isset($fortune_Main_Settings['fortune_border_width'])) {
        $fortune_border_width = $fortune_Main_Settings['fortune_border_width'];
    } else {
        $fortune_border_width = '3px';
    }
    if (isset($fortune_Main_Settings['fortune_max_width'])) {
        $fortune_max_width = $fortune_Main_Settings['fortune_max_width'];
    } else {
        $fortune_max_width = '800px';
    }
    if (isset($fortune_Main_Settings['fortune_cookie_exp'])) {
        $fortune_cookie_exp = $fortune_Main_Settings['fortune_cookie_exp'];
    } else {
        $fortune_cookie_exp = '1440';
    }
    if (isset($fortune_Main_Settings['fortune_popup_animation'])) {
        $fortune_popup_animation = $fortune_Main_Settings['fortune_popup_animation'];
    } else {
        $fortune_popup_animation = 'fortune_no_anim';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background_style'])) {
        $fortune_popup_background_style = $fortune_Main_Settings['fortune_popup_background_style'];
    } else {
        $fortune_popup_background_style = 'fortune_color';
    }
    if (isset($fortune_Main_Settings['fortune_auto_hide'])) {
        $fortune_auto_hide = $fortune_Main_Settings['fortune_auto_hide'];
    } else {
        $fortune_auto_hide = '';
    }
    if (isset($fortune_Main_Settings['fortune_buttons'])) {
        $fortune_buttons = $fortune_Main_Settings['fortune_buttons'];
    } else {
        $fortune_buttons = '';
    }
    if (isset($fortune_Main_Settings['fortune_fade_background'])) {
        $fortune_fade_background = $fortune_Main_Settings['fortune_fade_background'];
    } else {
        $fortune_fade_background = '';
    }
    if (isset($fortune_Main_Settings['fortune_only_eu'])) {
        $fortune_only_eu = $fortune_Main_Settings['fortune_only_eu'];
    } else {
        $fortune_only_eu = '';
    }
    if (isset($fortune_Main_Settings['fortune_block_cookies'])) {
        $fortune_block_cookies = $fortune_Main_Settings['fortune_block_cookies'];
    } else {
        $fortune_block_cookies = '';
    }
    if (isset($fortune_Main_Settings['fortune_blocked_content'])) {
        $fortune_blocked_content = $fortune_Main_Settings['fortune_blocked_content'];
    } else {
        $fortune_blocked_content = '';
    }
    if (isset($fortune_Main_Settings['fortune_blocked_content_text'])) {
        $fortune_blocked_content_text = $fortune_Main_Settings['fortune_blocked_content_text'];
    } else {
        $fortune_blocked_content_text = 'Sorry but this content is blocked. Accept cookies to allow this content!';
    }
    if (isset($fortune_Main_Settings['fortune_deny_button'])) {
        $fortune_deny_button = $fortune_Main_Settings['fortune_deny_button'];
    } else {
        $fortune_deny_button = '';
    }
    if (isset($fortune_Main_Settings['fortune_block_all_cookies'])) {
        $fortune_block_all_cookies = $fortune_Main_Settings['fortune_block_all_cookies'];
    } else {
        $fortune_block_all_cookies = '';
    }
    if (isset($fortune_Main_Settings['fortune_disable_loggedin'])) {
        $fortune_disable_loggedin = $fortune_Main_Settings['fortune_disable_loggedin'];
    } else {
        $fortune_disable_loggedin = '';
    }
    if (isset($fortune_Main_Settings['fortune_deny_button_text'])) {
        $fortune_deny_button_text = $fortune_Main_Settings['fortune_deny_button_text'];
    } else {
        $fortune_deny_button_text = 'Deny';
    }
    if (isset($fortune_Main_Settings['fortune_custom_css'])) {
        $fortune_custom_css = $fortune_Main_Settings['fortune_custom_css'];
    } else {
        $fortune_custom_css = '';
    }
    if (isset($fortune_Main_Settings['fortune_distance_bottom'])) {
        $fortune_distance_bottom = $fortune_Main_Settings['fortune_distance_bottom'];
    } else {
        $fortune_distance_bottom = 'auto';
    }
    if (isset($fortune_Main_Settings['fortune_distance_top'])) {
        $fortune_distance_top = $fortune_Main_Settings['fortune_distance_top'];
    } else {
        $fortune_distance_top = '0px';
    }
    if (isset($fortune_Main_Settings['fortune_distance_left'])) {
        $fortune_distance_left = $fortune_Main_Settings['fortune_distance_left'];
    } else {
        $fortune_distance_left = 'auto';
    }
    if (isset($fortune_Main_Settings['fortune_distance_right'])) {
        $fortune_distance_right = $fortune_Main_Settings['fortune_distance_right'];
    } else {
        $fortune_distance_right = 'auto';
    }
    if (isset($fortune_Main_Settings['fortune_padding'])) {
        $fortune_padding = $fortune_Main_Settings['fortune_padding'];
    } else {
        $fortune_padding = '10px';
    }
    if (isset($fortune_Main_Settings['fortune_popup_background_image'])) {
        $fortune_popup_background_image = $fortune_Main_Settings['fortune_popup_background_image'];
    } else {
        $fortune_popup_background_image = '';
    }
    if (isset($fortune_Main_Settings['fortune_max_height'])) {
        $fortune_max_height = $fortune_Main_Settings['fortune_max_height'];
    } else {
        $fortune_max_height = '';
    }
    if (isset($fortune_Main_Settings['fortune_font_size'])) {
        $fortune_font_size = $fortune_Main_Settings['fortune_font_size'];
    } else {
        $fortune_font_size = '14px';
    }
    if (isset($fortune_Main_Settings['fortune_font_type'])) {
        $fortune_font_type = $fortune_Main_Settings['fortune_font_type'];
    } else {
        $fortune_font_type = 'Helvetica, Arial, sans-serif';
    }
    if (isset($fortune_Main_Settings['fortune_cookie_accept_delete_text'])) {
        $fortune_cookie_accept_delete_text = $fortune_Main_Settings['fortune_cookie_accept_delete_text'];
    } else {
        $fortune_cookie_accept_delete_text = 'Are you sure you want to change your mind about cookie consent policy?';
    }
    if (isset($fortune_Main_Settings['fortune_cookie_delete_text'])) {
        $fortune_cookie_delete_text = $fortune_Main_Settings['fortune_cookie_delete_text'];
    } else {
        $fortune_cookie_delete_text = 'Show cookiebar again';
    }
    if (isset($fortune_Main_Settings['fortune_rounded_corners'])) {
        $fortune_rounded_corners = $fortune_Main_Settings['fortune_rounded_corners'];
    } else {
        $fortune_rounded_corners = '';
    }
    if (isset($fortune_Main_Settings['fortune_new_line'])) {
        $fortune_new_line = $fortune_Main_Settings['fortune_new_line'];
    } else {
        $fortune_new_line = '';
    }
    if (isset($fortune_Main_Settings['fortune_new_line_all'])) {
        $fortune_new_line_all = $fortune_Main_Settings['fortune_new_line_all'];
    } else {
        $fortune_new_line_all = '';
    }
    if (isset($fortune_Main_Settings['fortune_auto_accept'])) {
        $fortune_auto_accept = $fortune_Main_Settings['fortune_auto_accept'];
    } else {
        $fortune_auto_accept = '';
    }
    if (isset($fortune_Main_Settings['fortune_outside_close_accept'])) {
        $fortune_outside_close_accept = $fortune_Main_Settings['fortune_outside_close_accept'];
    } else {
        $fortune_outside_close_accept = '';
    }
    if (isset($fortune_Main_Settings['fortune_outside_close'])) {
        $fortune_outside_close = $fortune_Main_Settings['fortune_outside_close'];
    } else {
        $fortune_outside_close = '';
    }
    if (isset($fortune_Main_Settings['fortune_center_popup'])) {
        $fortune_center_popup = $fortune_Main_Settings['fortune_center_popup'];
    } else {
        $fortune_center_popup = '';
    }
    if (isset($fortune_Main_Settings['fortune_advanced_settings'])) {
        $fortune_advanced_settings = $fortune_Main_Settings['fortune_advanced_settings'];
    } else {
        $fortune_advanced_settings = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_bold'])) {
        $fortune_fonts_bold = $fortune_Main_Settings['fortune_fonts_bold'];
    } else {
        $fortune_fonts_bold = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_italic'])) {
        $fortune_fonts_italic = $fortune_Main_Settings['fortune_fonts_italic'];
    } else {
        $fortune_fonts_italic = '';
    }
    if (isset($fortune_Main_Settings['fortune_fonts_underline'])) {
        $fortune_fonts_underline = $fortune_Main_Settings['fortune_fonts_underline'];
    } else {
        $fortune_fonts_underline = '';
    }
    if (isset($fortune_Main_Settings['fortune_dnt_check'])) {
        $fortune_dnt_check = $fortune_Main_Settings['fortune_dnt_check'];
    } else {
        $fortune_dnt_check = '';
    }
?>
<script>
                var fortune_admin_json = {
                    fortune_enabled: '<?php
    echo $fortune_enabled;
?>',
                    fortune_popup_once: '<?php
    echo $fortune_popup_once;
?>',
                    fortune_dnt_check: '<?php
    echo $fortune_dnt_check;
?>',
                    fortune_popup_style: '<?php
    echo $fortune_popup_style;
?>',
                    fortune_message: '<?php
    echo $fortune_message;
?>',
                    fortune_close_message: '<?php
    echo $fortune_close_message;
?>',
                    fortune_more_info: '<?php
    echo $fortune_more_info;
?>',
                    fortune_more_link: '<?php
    echo $fortune_more_link;
?>',
                    fortune_popup_background: '<?php
    echo $fortune_popup_background;
?>',
                    fortune_popup_text_col: '<?php
    echo $fortune_popup_text_col;
?>',
                    fortune_popup_links_col: '<?php
    echo $fortune_popup_links_col;
?>',
                    fortune_panel_sticks: '<?php
    echo $fortune_panel_sticks;
?>',
                    fortune_more_link_text: '<?php
    echo $fortune_more_link_text;
?>',
                    fortune_auto_hide: '<?php
    echo $fortune_auto_hide;
?>',
                    fortune_auto_hide_time: '<?php
    echo $fortune_auto_hide_time;
?>',
                    fortune_border: '<?php
    echo $fortune_border;
?>',
                    fortune_border_color: '<?php
    echo $fortune_border_color;
?>',
                    fortune_border_width: '<?php
    echo $fortune_border_width;
?>',
                    fortune_buttons: '<?php
    echo $fortune_buttons;
?>',
                    fortune_popup_background_style: '<?php
    echo $fortune_popup_background_style;
?>',
                    fortune_popup_animation: '<?php
    echo $fortune_popup_animation;
?>',
                    fortune_max_width: '<?php
    echo $fortune_max_width;
?>',
                    fortune_fade_background: '<?php
    echo $fortune_fade_background;
?>',
                    fortune_only_eu: '<?php
    echo $fortune_only_eu;
?>',
                    fortune_block_cookies: '<?php
    echo $fortune_block_cookies;
?>',
                    fortune_blocked_content: '<?php
    echo $fortune_blocked_content;
?>',
                    fortune_blocked_content_text: '<?php
    echo $fortune_blocked_content_text;
?>',
                    fortune_deny_button: '<?php
    echo $fortune_deny_button;
?>',
                    fortune_deny_button_text: '<?php
    echo $fortune_deny_button_text;
?>',
                    fortune_block_all_cookies: '<?php
    echo $fortune_block_all_cookies;
?>',
                    fortune_disable_loggedin: '<?php
    echo $fortune_disable_loggedin;
?>',
                    fortune_custom_css: '<?php
    echo $fortune_custom_css;
?>',
                    fortune_rounded_corners: '<?php
    echo $fortune_rounded_corners;
?>',
                    fortune_distance_right: '<?php
    echo $fortune_distance_right;
?>',
                    fortune_distance_left: '<?php
    echo $fortune_distance_left;
?>',
                    fortune_distance_top: '<?php
    echo $fortune_distance_top;
?>',
                    fortune_distance_bottom: '<?php
    echo $fortune_distance_bottom;
?>',
                    fortune_padding: '<?php
    echo $fortune_padding;
?>',
                    fortune_new_line: '<?php
    echo $fortune_new_line;
?>',
                    fortune_new_line_all: '<?php
    echo $fortune_new_line_all;
?>',
                    fortune_auto_accept: '<?php
    echo $fortune_auto_accept;
?>',
                    fortune_outside_close_accept: '<?php
    echo $fortune_outside_close_accept;
?>',
                    fortune_outside_close: '<?php
    echo $fortune_outside_close;
?>',
                    fortune_center_popup: '<?php
    echo $fortune_center_popup;
?>',
                    fortune_advanced_settings: '<?php
    echo $fortune_advanced_settings;
?>',
                    fortune_popup_background_image: '<?php
    echo $fortune_popup_background_image;
?>',
                    fortune_max_height: '<?php
    echo $fortune_max_height;
?>',
                    fortune_font_size: '<?php
    echo $fortune_font_size;
?>',
                    fortune_font_type: '<?php
    echo str_replace('"', "", $fortune_font_type);
?>',
                    fortune_button_background: '<?php
    echo $fortune_button_background;
?>',
                    fortune_button_border: '<?php
    echo $fortune_button_border;
?>',
                    fortune_cookie_exp: '<?php
    echo $fortune_cookie_exp;
?>',
                    fortune_fonts_bold: '<?php
    echo $fortune_fonts_bold;
?>',
                    fortune_fonts_italic: '<?php
    echo $fortune_fonts_italic;
?>',
                    fortune_fonts_underline: '<?php
    echo $fortune_fonts_underline;
?>',
                    fortune_cookie_accept_delete_text: '<?php
    echo $fortune_cookie_accept_delete_text;
?>',
                    fortune_cookie_delete_text: '<?php
    echo $fortune_cookie_delete_text;
?>'
}
            </script>
            <script type="text/javascript">
            jQuery(document).ready(function() 
            {
                jQuery('#fb_image_button').click(function(){
                    tb_show('',"media-upload.php?type=image&TB_iframe=true");
                });
                
            });
            
            window.onload = mainChanged;
            function mainChanged()
            {
                if(jQuery('.input-checkbox').is(":checked"))
                {            
                    jQuery(".hideMain").show();
                }
                else
                {
                    jQuery(".hideMain").hide();
                }
                if(jQuery('#fortune_center_popup').is(":checked"))
                {            
                    jQuery("#left_dist").attr("readonly", "readonly");
                    jQuery("#right_dist").attr("readonly", "readonly"); 
                    jQuery("#left_dist").attr("title", "Disabled because 'Center popup' checkbox is checked!");
                    jQuery("#right_dist").attr("title", "Disabled because 'Center popup' checkbox is checked!"); 
                }
                else
                {
                    jQuery("#left_dist").removeAttr("readonly"); 
                    jQuery("#right_dist").removeAttr("readonly"); 
                    jQuery("#left_dist").removeAttr("title"); 
                    jQuery("#right_dist").removeAttr("title"); 
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_popup')
                {
                    jQuery('#fortune_center_popup_div').show();
                    jQuery('#fortune_center_popup_div2').show();
                }
                else
                {
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                }
                if(jQuery('#fortune_advanced_settings').is(":checked"))
                {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img1').hide();
                    jQuery('#img8').show();
                    jQuery('#img7').hide();
                }
                else
                {
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_top')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img3').hide();
                        jQuery('#img4').hide();
                        jQuery('#img5').hide();
                        jQuery('#img6').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img1').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_bottom')
                    {
                        jQuery('#img1').hide();
                        jQuery('#img3').hide();
                        jQuery('#img4').hide();
                        jQuery('#img5').hide();
                        jQuery('#img6').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img2').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_left_bot')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img1').hide();
                        jQuery('#img4').hide();
                        jQuery('#img5').hide();
                        jQuery('#img6').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img3').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_right_bot')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img3').hide();
                        jQuery('#img1').hide();
                        jQuery('#img5').hide();
                        jQuery('#img6').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img4').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_left_top')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img3').hide();
                        jQuery('#img4').hide();
                        jQuery('#img1').hide();
                        jQuery('#img6').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img5').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_right_top')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img3').hide();
                        jQuery('#img4').hide();
                        jQuery('#img5').hide();
                        jQuery('#img1').hide();
                        jQuery('#img7').hide();
                        jQuery('#img8').hide();
                        jQuery('#img6').show();
                    }
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_popup')
                    {
                        jQuery('#img2').hide();
                        jQuery('#img3').hide();
                        jQuery('#img4').hide();
                        jQuery('#img5').hide();
                        jQuery('#img6').hide();
                        jQuery('#img1').hide();
                        jQuery('#img8').hide();
                        jQuery('#img7').show();
                    }
                }
                if(jQuery('#fortune_advanced_settings').is(":checked"))
                {            
                    jQuery(".adv_set").show();
                }
                else
                {
                    jQuery(".adv_set").hide();
                }
                if(jQuery('#fortune_more_info').is(":checked"))
                {            
                    jQuery(".more_info_set").show();
                }
                else
                {
                    jQuery(".more_info_set").hide();
                }
                if(jQuery('#fortune_auto_hide').is(":checked"))
                {
                    jQuery(".auto_hide_me").show();
                }
                else
                {
                    jQuery(".auto_hide_me").hide();
                }
                if(jQuery('#fortune_fade_background').is(":checked"))
                {
                    jQuery(".fade_hide_me").show();
                }
                else
                {
                    jQuery(".fade_hide_me").hide();
                }
                if(jQuery('#fortune_deny_button').is(":checked"))
                {
                    jQuery(".hide_deny").show();
                }
                else
                {
                    jQuery(".hide_deny").hide();
                }
                if(jQuery('#fortune_border').is(":checked"))
                {
                    jQuery(".hide_border").show();
                }
                else
                {
                    jQuery(".hide_border").hide();
                }
                if(jQuery('#fortune_new_line').is(":checked"))
                {
                    jQuery(".new_line_hide").show();
                }
                else
                {
                    jQuery(".new_line_hide").hide();
                }
                if(jQuery('#fortune_blocked_content').is(":checked"))
                {
                    jQuery(".loggedin_disable").show();
                }
                else
                {
                    jQuery(".loggedin_disable").hide();
                }
                colorChanged();
            }
            function colorChanged()
            {
                if(jQuery('input[id=radio_gs_exp3]:radio:checked').val() === 'fortune_color')
                {
                    jQuery(".color_div").show();
                    jQuery(".image_div").hide();
                }
                if(jQuery('input[id=radio_gs_exp3]:radio:checked').val() === 'fortune_image')
                {
                    jQuery(".color_div").hide();
                    jQuery(".image_div").show();
                }
                if(jQuery('input[id=radio_gs_exp3]:radio:checked').val() === 'fortune_transparent')
                {
                    jQuery(".color_div").hide();
                    jQuery(".image_div").hide();
                }
                if(jQuery('#fortune_buttons').is(":checked"))
                {
                    jQuery(".color_but").show();
                }
                else
                {
                    jQuery(".color_but").hide();
                }
            }
            function centerChanged()
            {
                if(jQuery('#fortune_advanced_settings').is(":checked"))
                {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img1').hide();
                    jQuery('#img8').show();
                    jQuery('#img7').hide();
                }
                else
                {
                    sizesChanged('fromFunction');
                }
                if(jQuery('#fortune_center_popup').is(":checked"))
                {            
                    jQuery("#left_dist").attr("readonly", "readonly");
                    jQuery("#right_dist").attr("readonly", "readonly");  
                    jQuery("#left_dist").attr("title", "Disabled because 'Center popup' checkbox is checked!");
                    jQuery("#right_dist").attr("title", "Disabled because 'Center popup' checkbox is checked!");                     
                    jQuery('input#left_dist').val("50%");
                    jQuery('input#right_dist').val("auto");
                }
                else
                {
                    jQuery("#left_dist").removeAttr("readonly"); 
                    jQuery("#right_dist").removeAttr("readonly");
                    jQuery("#left_dist").removeAttr("title"); 
                    jQuery("#right_dist").removeAttr("title"); 
                }
                if(jQuery('#fortune_advanced_settings').is(":checked"))
                {            
                    jQuery(".adv_set").show();
                }
                else
                {
                    jQuery(".adv_set").hide();
                }
                if(jQuery('#fortune_more_info').is(":checked"))
                {            
                    jQuery(".more_info_set").show();
                }
                else
                {
                    jQuery(".more_info_set").hide();
                }
                if(jQuery('#fortune_auto_hide').is(":checked"))
                {
                    jQuery(".auto_hide_me").show();
                }
                else
                {
                    jQuery(".auto_hide_me").hide();
                }
                if(jQuery('#fortune_fade_background').is(":checked"))
                {
                    jQuery(".fade_hide_me").show();
                }
                else
                {
                    jQuery(".fade_hide_me").hide();
                }
                if(jQuery('#fortune_deny_button').is(":checked"))
                {
                    jQuery(".hide_deny").show();
                }
                else
                {
                    jQuery(".hide_deny").hide();
                }
                if(jQuery('#fortune_border').is(":checked"))
                {
                    jQuery(".hide_border").show();
                }
                else
                {
                    jQuery(".hide_border").hide();
                }
                if(jQuery('#fortune_new_line').is(":checked"))
                {
                    jQuery(".new_line_hide").show();
                }
                else
                {
                    jQuery(".new_line_hide").hide();
                }
                if(jQuery('#fortune_blocked_content').is(":checked"))
                {
                    jQuery(".loggedin_disable").show();
                }
                else
                {
                    jQuery(".loggedin_disable").hide();
                }
            }
            function sizesChanged($val = "none")
            {
                if($val !== 'fromFunction')
                {
                    if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_popup')
                    {
                        jQuery('#fortune_center_popup').attr('checked', true);
                    }
                    else
                    {
                        jQuery('#fortune_center_popup').attr('checked', false);
                    }
                }
                jQuery("#left_dist").removeAttr("readonly"); 
                jQuery("#right_dist").removeAttr("readonly");
                jQuery("#left_dist").removeAttr("title"); 
                jQuery("#right_dist").removeAttr("title"); 
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_top')
                {
                    jQuery('input#top_dist').val("0px");
                    jQuery('input#bot_dist').val("auto");
                    jQuery('input#left_dist').val("0px");
                    jQuery('input#right_dist').val("0px");
                    jQuery('input#max_width').val("");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img1').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_bottom')
                {
                    jQuery('input#top_dist').val("auto");
                    jQuery('input#bot_dist').val("0px");
                    jQuery('input#left_dist').val("0px");
                    jQuery('input#right_dist').val("0px");
                    jQuery('input#max_width').val("");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img1').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img2').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_left_bot')
                {
                    jQuery('input#top_dist').val("auto");
                    jQuery('input#bot_dist').val("10px");
                    jQuery('input#left_dist').val("10px");
                    jQuery('input#right_dist').val("auto");
                    jQuery('input#max_width').val("300px");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img1').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img3').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_right_bot')
                {
                    jQuery('input#top_dist').val("auto");
                    jQuery('input#bot_dist').val("10px");
                    jQuery('input#left_dist').val("auto");
                    jQuery('input#right_dist').val("10px");
                    jQuery('input#max_width').val("300px");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img1').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img4').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_left_top')
                {
                    jQuery('input#top_dist').val("10px");
                    jQuery('input#bot_dist').val("auto");
                    jQuery('input#left_dist').val("10px");
                    jQuery('input#right_dist').val("auto");
                    jQuery('input#max_width').val("300px");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img1').hide();
                    jQuery('#img6').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img5').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_panel_right_top')
                {
                    jQuery('input#top_dist').val("10px");
                    jQuery('input#bot_dist').val("auto");
                    jQuery('input#left_dist').val("auto");
                    jQuery('input#right_dist').val("10px");
                    jQuery('input#max_width').val("300px");
                    jQuery('#fortune_center_popup_div').hide();
                    jQuery('#fortune_center_popup_div2').hide();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img1').hide();
                    jQuery('#img7').hide();
                    jQuery('#img8').hide();
                    jQuery('#img6').show();
                    }
                }
                if(jQuery('input[id=radio_gs_exp]:radio:checked').val() === 'fortune_popup')
                {
                    jQuery('input#top_dist').val("30%");
                    jQuery('input#bot_dist').val("auto");
                    jQuery('input#left_dist').val("50%");
                    jQuery('input#right_dist').val("auto");
                    jQuery('input#max_width').val("300px");
                    jQuery('#fortune_center_popup_div').show();
                    jQuery('#fortune_center_popup_div2').show();
                    if(!jQuery('#fortune_advanced_settings').is(":checked"))
                    {
                    jQuery('#img2').hide();
                    jQuery('#img3').hide();
                    jQuery('#img4').hide();
                    jQuery('#img5').hide();
                    jQuery('#img6').hide();
                    jQuery('#img1').hide();
                    jQuery('#img8').hide();
                    jQuery('#img7').show();
                    }
                    else
                    {
                        jQuery("#left_dist").attr("readonly", "readonly");
                        jQuery("#right_dist").attr("readonly", "readonly");  
                    }
                }
            }
    </script>
    <script>
    function fortune_delete_cookies()
    {
        if (confirm("Are you sure you want to delete all cookies from your page?") == true) {
            var data = {
                action: 'fortune_my_action'
            };
                jQuery.post(ajaxurl, data, function(response) {
            });
        }
    }
    </script>
    <script>
    
(function( $ ) {

  var settings;

  var methods = {
    init : function(options) {

      settings = $.extend( {
        'hide_fallbacks' : false,
        'selected' : function(style) {},
        'opened' : function() {},
        'closed' : function() {},
        'initial' : '',
        'fonts' : []
      }, options);

      var root = this;
      var $root = $(this);
      root.selectedCallback = settings['selected'];
      root.openedCallback = settings['opened'];
      root.closedCallback = settings['closed'];
      var visible = false;
      var selected = false;
      var openedClass = 'fontSelectOpen';

      var displayName = function(font) {
        if (settings['hide_fallbacks'])
          return font.substr(0, font.indexOf(','));
        else
          return font;
      }

      var select = function(font) {
        root.find('span').html(displayName(font).replace(/["']{1}/gi,""));
        root.css('font-family', font);
        selected = font;

        root.selectedCallback(selected);
      }

      var positionUl = function() {
        var left, top;
        left = $(root).offset().left;
        top = $(root).offset().top + $(root).outerHeight();

        $(ul).css({
          'position': 'absolute',
          'left': left + 'px',
          'top': top + 'px',
          'width': $(root).outerWidth() + 'px'
        });
      }

      var closeUl = function() {
        ul.slideUp('fast', function() {
          visible = false;
        });

        $root.removeClass(openedClass);

        root.closedCallback();
      }

      var openUi = function() {
        ul.slideDown('fast', function() {
          visible = true;
        });

        $root.addClass(openedClass);

        root.openedCallback();
      }

      $root.prepend('<span>' + settings['initial'].replace(/'/g,'&#039;') + '</span>');
      var ul = $('<ul class="fontSelectUl"></ul>').appendTo('body');
      ul.hide();
      positionUl();

      for (var i = 0; i < settings['fonts'].length; i++) {
        var item = $('<li>' + displayName(settings['fonts'][i]) + '</li>').appendTo(ul);
        $(item).css('font-family', settings['fonts'][i]);
      }

      if (settings['initial'] != '')
        select(settings['initial']);

      ul.find('li').click(function() {

        if (!visible)
          return;

        positionUl();
        closeUl();

        select($(this).css('font-family'));
      });

      $root.click(function(event) {

        if (visible)
          return;

        event.stopPropagation();

        positionUl();
        openUi();
      });

      $('html').click(function() {
        if (visible)
        {
          closeUl();
        }
      })
    },
    selected : function() {
      return this.css('font-family');
    },
    select : function(font) {
      this.find('span').html(font.substr(0, font.indexOf(',')).replace(/["']{1}/gi,""));
      this.css('font-family', font);
      selected = font;
    }
  };

  $.fn.fontSelector = function(method) {
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.fontSelector' );
    }
  }
}) ( jQuery );

jQuery(function() {
		jQuery('#fontSelect').fontSelector({
			'hide_fallbacks' : true,
			'initial' : '<?php
    echo $fortune_font_type;
?>',
			'selected' : function(style) { jQuery('input#fortune_font_type').val(style); },
			'fonts' : [
				'Arial,Arial,Helvetica,sans-serif',
				'Arial Black,Arial Black,Gadget,sans-serif',
				'Comic Sans MS,Comic Sans MS,cursive',
				'Courier New,Courier New,Courier,monospace',
				'Georgia,Georgia,serif',
                'Helvetica, Arial, sans-serif',
				'Impact,Charcoal,sans-serif',
				'Lucida Console,Monaco,monospace',
				'Lucida Sans Unicode,Lucida Grande,sans-serif',
				'Palatino Linotype,Book Antiqua,Palatino,serif',
				'Tahoma,Geneva,sans-serif',
				'Times New Roman,Times,serif',
				'Trebuchet MS,Helvetica,sans-serif',
				'Verdana,Geneva,sans-serif',
				'Gill Sans,Geneva,sans-serif'
				]
		});
	});
</script>
<div ng-app="forsettingsApp" ng-controller="forsettingsController" ng-cloak ng-init="initialized()">
<div>
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Fortune Cookie Plugin Main Switch:</b></span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Fortune Cookie Consent Policy Plugin.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="fortune_enabled" name="fortune_Main_Settings[fortune_enabled]" onChange="mainChanged()" <?php
    if ($fortune_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="fortune_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                <table>
  <tr><td><b>Preview:</b><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Here you can preview your popup style.";
?>
                        </div>
                    </div></td><td>
                        <div>
                        <img id="img1" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/up.png';
?>" alt="Up"><img id="img2" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/down.png';
?>" alt="Down"><img id="img3" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/left_down.png';
?>" alt="left down"><img id="img4" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/right_down.png';
?>" alt="right down"><img id="img5" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/left_up.png';
?>" alt="left up"><img id="img6" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/right_up.png';
?>" alt="right_up"><img id="img7" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/popup.png';
?>" alt="popup"><img id="img8" src="<?php
    echo plugin_dir_url(dirname(__FILE__)) . 'images/custom.png';
?>" alt="custom">
                    </div>
                        </td>
                        </tr>
                        <tr><td><hr/></td><td><hr/></td></tr>
                        <tr><td><h3><b>Position and Size Settings:</b></h3></td></tr>
                <tr><td>
                        <span class="gs-sub-heading"><b>Notification Style:</b></span>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "How the message will be displayed to the user. You can choose between top notification panel, bottom notification panel, right up or down, left up or down notification panels or pupup style panel.";
?>
                            </div>
                        </div>
                        </td><td>                     
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_top"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Top Panel Style</label>&nbsp;<br/> 
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_bottom"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Bottom Panel Style</label>&nbsp; <br/>
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_right_bot"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Round Panel Bottom Right</label>&nbsp; <br/>
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_left_bot"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Round Panel Bottom Left</label>&nbsp; <br/>
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_right_top"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Round Panel Top Right</label>&nbsp; <br/>
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_panel_left_top"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Round Panel Top Left</label>&nbsp; <br/>
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_style]" value="fortune_popup"
                            id="radio_gs_exp" ng-model="settings.fortune_popup_style" onclick="sizesChanged()"> Popup Style</label>&nbsp; <br/><br/>
                        
                        </td>
                        </tr>
                        <tr><td><hr/></td><td><hr/></td></tr>
                        <tr><td><h3><b>Advanced Position and Size Settings:</b></h3></td></tr>
                    <tr><td>
                    <div id="fortune_center_popup_div">
                    <b>Center Popup:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to center the popup on every screen type?";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div id="fortune_center_popup_div2">
                    <input type="checkbox" id="fortune_center_popup" name="fortune_Main_Settings[fortune_center_popup]" onclick="centerChanged()" <?php
    if ($fortune_center_popup == 'on')
        echo ' checked ';
?>>
                        
                    </div>
                    </td></tr>
                    <tr><td>
                    <div id="fortune_center_popup_div">
                    <b>Enable Advanced Position and Size Settings:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable advanced position and size settings? I recommend that you enable this only if you have prior experience with CSS, or you are sure that you know what you are doing.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div id="fortune_center_popup_div2">
                    <input type="checkbox" id="fortune_advanced_settings" name="fortune_Main_Settings[fortune_advanced_settings]" onclick="centerChanged()" <?php
    if ($fortune_advanced_settings == 'on')
        echo ' checked ';
?>>
                        
                    </div>
                    </td></tr>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Distance to Top Margin of the Page:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Distance (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) fron the upper margin of the popup, to the top margin of your webpage.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="top_dist" name="fortune_Main_Settings[fortune_distance_top]" ng-model="settings.fortune_distance_top" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Distance to Bottom Margin of the Page:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Distance (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) fron the bottom margin of the popup, to the bottom margin of your webpage.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="bot_dist" name="fortune_Main_Settings[fortune_distance_bottom]" ng-model="settings.fortune_distance_bottom" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Distance to Left Margin of the Page:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Distance (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) fron the left margin of the popup, to the left margin of your webpage.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="left_dist" name="fortune_Main_Settings[fortune_distance_left]" ng-model="settings.fortune_distance_left" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Distance to Right Margin of the Page:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Distance (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) fron the right margin of the popup, to the right margin of your webpage.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="right_dist" name="fortune_Main_Settings[fortune_distance_right]" ng-model="settings.fortune_distance_right" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>   
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Popup Max Width:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The maximum width (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) your popup will have. Set this to a lower value to make upper or lower bar panel notification types to not span until the edge of your screen - leave blank if you don't whant to control this.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="max_width" name="fortune_Main_Settings[fortune_max_width]" ng-model="settings.fortune_max_width" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="adv_set">
                    <b>Popup Max Height:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The maximum height (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) your popup will have. Set this to a lower value to make your popup thinner - leave blank if you don't whant to control this.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="adv_set">
                    <input type="text" id="max_width" name="fortune_Main_Settings[fortune_max_height]" ng-model="settings.fortune_max_height" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)">
                    </div>    
                    </td></tr>
        </div>
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td><h3><b>Message Settings:</b></h3></td></tr>
        <div>
                    <tr><td>
                    <b>Main Message Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The main message to be shown. This should be the text that warns the user about your site using cookies.";
?>
                        </div>
                    </div>
                    </td><td>
                    <textarea rows="4" cols="44" name="fortune_Main_Settings[fortune_message]" ng-model="settings.fortune_message"></textarea>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>'Accept Cookies' Button Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The Accept message to be shown to the user. Usually a simple 'Accept' will do it.";
?>
                        </div>
                    </div>
                    </td><td>
                    <textarea rows="2" cols="44" name="fortune_Main_Settings[fortune_close_message]" ng-model="settings.fortune_close_message"></textarea>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Enable 'More Info' Button:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to include a link with 'More Info'?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_more_info" name="fortune_Main_Settings[fortune_more_info]" <?php
    if ($fortune_more_info == 'on')
        echo ' checked ';
?> onclick="centerChanged()">
                        
                    </td></tr>
        </div>
        <div>
       
        
                    <tr><td>
                    <div class="more_info_set">
                    <b>'More Info' Button Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text of the 'More Info' button or link.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="more_info_set">
                    <textarea rows="2" cols="44" name="fortune_Main_Settings[fortune_more_link_text]" ng-model="settings.fortune_more_link_text"></textarea>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="more_info_set">
                    <b>'More Info' Link Adress:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The adress where the 'More Info' link or button will point to. This is usually your 'Privacy Policy' or 'Use of cookies' page.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="more_info_set">
                    <input type="URL" list="the_links" name="fortune_Main_Settings[fortune_more_link]" ng-model="settings.fortune_more_link" style="width:301px"> 
                        <datalist id="the_links">
                            <?php
    $pages = get_pages();
    foreach ($pages as $page) {
        $option = '<option value="' . $page->guid . '" ';
        $option .= '>';
        $option .= $page->post_title;
        $option .= '</option>';
        echo $option;
    }
?>
                        </datalist>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Enable 'Deny' Button:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show a 'Deny' button to the user? This button will not accept cookies and will not enable hidden content by this plugins 'Blocked Content Placeholder' feature. On next page visit, user will be notified once again about accepting cookies on your site.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_deny_button" name="fortune_Main_Settings[fortune_deny_button]" onclick="centerChanged();"<?php
    if ($fortune_deny_button == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="hide_deny">
                    <b>'Deny' Button Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "What do you want to be the text of the 'Deny Cookies' button? Usually a simple 'Deny' will do.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="hide_deny">
                    <textarea rows="2" cols="44" name="fortune_Main_Settings[fortune_deny_button_text]" ng-model="settings.fortune_deny_button_text"></textarea>
                    </div>
                    </td></tr>
        </div>
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td><h3><b>Common Options:</b></h3></td></tr>
        <div>
                    <tr><td>
                    <b>Fade Background:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to fade background when popup is visible? This will gray out the background of your popup, furter increasing popup's visibility.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_fade_background" name="fortune_Main_Settings[fortune_fade_background]" onclick="centerChanged()" <?php
    if ($fortune_fade_background == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="fade_hide_me">
                    <b>Clicking Outside the Popup Will Close It:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want that clicking outside the popup will close it? If user clicks on the gray area outside the popup, it will be closed.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="fade_hide_me">
                    <input type="checkbox" id="fortune_outside_close" name="fortune_Main_Settings[fortune_outside_close]" <?php
    if ($fortune_outside_close == 'on')
        echo ' checked ';
?>>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="fade_hide_me">
                    <b>And Also Will Accept Cookies:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Checking this option will result in the fact that a user clicks on the gray area outside the popup, it will be closed, and also the cookies will be accepted, so the popup will not disturb the user further more.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="fade_hide_me">
                    <input type="checkbox" id="fortune_outside_close_accept" name="fortune_Main_Settings[fortune_outside_close_accept]" <?php
    if ($fortune_outside_close_accept == 'on')
        echo ' checked ';
?>>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Auto Hide Popup After Delay:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to auto hide the popup after a predefined delay?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_auto_hide" name="fortune_Main_Settings[fortune_auto_hide]" onclick="centerChanged()" <?php
    if ($fortune_auto_hide == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="auto_hide_me">
                    <b>Auto Accept Cookies at Popup Auto Hide:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "When the popup is automatically hidden, do you want to also accept the cookies for the user?";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="auto_hide_me">
                    <input type="checkbox" id="fortune_auto_accept" name="fortune_Main_Settings[fortune_auto_accept]" <?php
    if ($fortune_auto_accept == 'on')
        echo ' checked ';
?>>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="auto_hide_me">
                    <b>Hide After (ms):</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The delay (in milliseconds) until the popup is hidden. Note that this filed is in milliseconds, so 5000 will be equal to 5 seconds.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="auto_hide_me">
                    <input type="text" name="fortune_Main_Settings[fortune_auto_hide_time]" ng-model="settings.fortune_auto_hide_time" pattern="([0-9])+">
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Show Popup to Users Only in the EU:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show the plugin policy popup only to the users that are browsing from inside the EU? Checking this feature will not disturb users outside the EU law coverage.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_only_eu" name="fortune_Main_Settings[fortune_only_eu]" <?php
    if ($fortune_only_eu == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Block Cookies Until User Does Not Accept Cookies:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable deployment of cookies until user accepts them? This option must be checked if you want to fully comply to the EU Cookie Regulation.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_block_cookies" name="fortune_Main_Settings[fortune_block_cookies]" <?php
    if ($fortune_block_cookies == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Disabled Popup for Logged in Users:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable plugin displaying to users who are logged in to you website?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_disable_loggedin" name="fortune_Main_Settings[fortune_disable_loggedin]" <?php
    if ($fortune_disable_loggedin == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Cookie life time (in minutes):</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The delay (in minutes) after which the cookie will be deleted. Note that this filed is in minutes, so 1 day will be equal to 1440 seconds. Note that after the cookie will be delted, the popup will be shown once again for that user.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="text" name="fortune_Main_Settings[fortune_cookie_exp]" ng-model="settings.fortune_cookie_exp" pattern="([0-9])+"> 
                    </td></tr>
        </div>
        
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td><h3><b>Styling Options:</b></h3></td></tr>
        <tr><td>
                        <span class="gs-sub-heading"><b>Animation Style:</b></span>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable animations for popup closing? You can choose between slide up or down and fade out animations.";
?>
                            </div>
                        </div>
                        </td><td>                     
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_animation]" value="fortune_no_anim"
                            id="radio_gs_exp2" ng-model="settings.fortune_popup_animation"> No Animation</label>&nbsp; 
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_animation]" value="fortune_slide_anim"
                            id="radio_gs_exp2" ng-model="settings.fortune_popup_animation"> Slide</label>&nbsp; 
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_animation]" value="fortune_fade_anim"
                            id="radio_gs_exp2" ng-model="settings.fortune_popup_animation"> Fade</label>&nbsp;  
                        
                        </td></tr>
        <div>
                    <tr><td>
                    <b>Text Padding:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Padding (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) inside the div (if the text is too near the popup edge, increase this value).";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="text" name="fortune_Main_Settings[fortune_padding]" ng-model="settings.fortune_padding" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)" style="min-width: 301px;">
                        
                    </td></tr>
        </div>
        <tr><td>
                        <span class="gs-sub-heading"><b>Background Style:</b></span>
                        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The style of the popup background. You can choose between: solid color background, transparent background and an image as a background.";
?>
                            </div>
                        </div>
                        </td><td>                     
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_background_style]" value="fortune_color"
                            id="radio_gs_exp3" ng-model="settings.fortune_popup_background_style" onclick="colorChanged();"> Solid Color</label>&nbsp; 
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_background_style]" value="fortune_transparent"
                            id="radio_gs_exp3" ng-model="settings.fortune_popup_background_style" onclick="colorChanged();"> Transparent</label>&nbsp; 
                        <label><input type="radio" name="fortune_Main_Settings[fortune_popup_background_style]" value="fortune_image"
                            id="radio_gs_exp3" ng-model="settings.fortune_popup_background_style" onclick="colorChanged();"> Image</label>&nbsp;  
                        
                        </td></tr>
        <div>
                    <tr><td>
                    <div class="color_div">
                    <b>Popup Background Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the backgound of your popup. Select it with the provided color picker tool.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="color_div">
                    <input type="color" name="fortune_Main_Settings[fortune_popup_background]" ng-model="settings.fortune_popup_background">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="image_div">
                    <b>Popup Background Image Link:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The link to the image which will be set as the backgound of your popup. This must be a valid link that points to a valid image.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="image_div">
                    <input type="url" validator="url" name="fortune_Main_Settings[fortune_popup_background_image]" ng-model="settings.fortune_popup_background_image" placeholder="http://www.mydomain.com/my_image.jpg" style="min-width: 301px;">
                    <input id="fb_image_button" class="button" type="button" value="Choose image" />  
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Popup Text Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the text which will be show in the popup. Chose it with the provided color picker.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="color" name="fortune_Main_Settings[fortune_popup_text_col]" ng-model="settings.fortune_popup_text_col">
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Popup Closing Link Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the links (including the closing link) show in your popup. Chose it with the provided color picker.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="color" name="fortune_Main_Settings[fortune_popup_links_col]" ng-model="settings.fortune_popup_links_col">
                        
                    </td></tr>
        </div>

        <div>
                    <tr><td>
                    <b>Show Popup Border:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show a border around the popup? Modify the border settings with the options below.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_border" name="fortune_Main_Settings[fortune_border]" onclick="centerChanged();" <?php
    if ($fortune_border == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="hide_border">
                    <b>Border Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the popup border. Chose it with the provided color picker.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="hide_border">
                    <input type="color" name="fortune_Main_Settings[fortune_border_color]" ng-model="settings.fortune_border_color">
                    </div>   
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="hide_border">
                    <b>Border Width:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The width of the popup border. Set this to any value (in <a href='https://www.w3.org/Style/Examples/007/units.en.html' target='_blank'>measurement units</a>) you desire.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="hide_border">
                    <input type="text" name="fortune_Main_Settings[fortune_border_width]" ng-model="settings.fortune_border_width" pattern="(-)?(\d*)(px|%|auto|initial|inherit|em|cm|mm|in|pt|pc)"  style="min-width: 301px;">
                    </div>    
                    </td></tr>
        </div>

        <div>
                    <tr><td>
                    <b>Rounded Popup Corners:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to display your popup with rounded corners? The popup will be displayed as an oval form.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_rounded_corners" name="fortune_Main_Settings[fortune_rounded_corners]" <?php
    if ($fortune_rounded_corners == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Buttons are on a New Line:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to place the 'Accept', 'More Info' and 'Deny' buttons on a new line?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_new_line" name="fortune_Main_Settings[fortune_new_line]" onclick="centerChanged()" <?php
    if ($fortune_new_line == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="new_line_hide">
                    <b>Every Button is on a New Line:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Should every button be on a new line?";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="new_line_hide">
                    <input type="checkbox" id="fortune_new_line_all" name="fortune_Main_Settings[fortune_new_line_all]" <?php
    if ($fortune_new_line_all == 'on')
        echo ' checked ';
?>>
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Show Buttons in Place of Links:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show buttons in place of links?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_buttons" name="fortune_Main_Settings[fortune_buttons]" onclick="colorChanged();" <?php
    if ($fortune_buttons == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="color_but">
                    <b>Button Background Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the backgound of your buttons. Select it with the provided color picker tool.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="color_but">
                    <input type="color" name="fortune_Main_Settings[fortune_button_background]" ng-model="settings.fortune_button_background">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="color_but">
                    <b>Button Border Color:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The color of the border of your buttons. Select it with the provided color picker tool.";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="color_but">
                    <input type="color" name="fortune_Main_Settings[fortune_button_border]" ng-model="settings.fortune_button_border">
                    </div>
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Popup Font Size:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The size of the fonts in your popup (default is 14). Note that you must enter the font size in pixels (the inputed value must end with px - ex: 14px).";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="text" id="fortune_font_size" name="fortune_Main_Settings[fortune_font_size]" ng-model="settings.fortune_font_size" pattern="([0-9])+px" style="min-width: 301px;">
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Popup Font Type:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose the font type of your inputed text. If you want other fonts for your popup, send me an email and I will provide it for you in a future plugin update.";
?>
                        </div>
                    </div>
                    </td><td>
                    <div id="fontSelect" class="fontSelect">
                        <div class="arrow-down"></div>
                    </div> 
                    <input type="hidden" id="fortune_font_type" name="fortune_Main_Settings[fortune_font_type]" ng-model="settings.fortune_font_type">
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Bold Fonts:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show bold fonts in you popup?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_fonts_bold" name="fortune_Main_Settings[fortune_fonts_bold]"<?php
    if ($fortune_fonts_bold == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Italic Fonts:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show italic fonts in you popup?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_fonts_italic" name="fortune_Main_Settings[fortune_fonts_italic]"<?php
    if ($fortune_fonts_italic == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Underline Fonts:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show underline fonts in you popup?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_fonts_underline" name="fortune_Main_Settings[fortune_fonts_underline]"<?php
    if ($fortune_fonts_underline == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td>
        <h3><b>Miscellaneous Settings:</b></h3></td></tr>
        <div>
                    <tr><td>
                    <b>Panel Sticks to it's Initial Position:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want the panel to stick to the top of the page, or you would like users to be able to scroll down and hide the panel? This feature lets you place your popup on a fixed spot on your webpage (and the user can scroll past it).";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_panel_sticks" name="fortune_Main_Settings[fortune_panel_sticks]" <?php
    if ($fortune_panel_sticks == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Block All Cookies:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to disable all cookies on your webpage (regardless if users accept them or not)? Caution! This feature will break many other plugins and WordPress features that use plugins! Use this with caution, and only if you know what you're doing.";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_block_all_cookies" name="fortune_Main_Settings[fortune_block_all_cookies]" <?php
    if ($fortune_block_all_cookies == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Custom CSS (for Advanced Users):</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert here you custom CSS for the popup. Insert here CSS code only if you know what you are doing and have experience with CSS! Use this feature with great caution, bacause improper usage can break your page!";
?>
                        </div>
                    </div>
                    </td><td>
                    <textarea rows="5" cols="44" name="fortune_Main_Settings[fortune_custom_css]" ng-model="settings.fortune_custom_css"></textarea>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Show Only Once per Visitor:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to show the message only once per visitor? This is an experimental feature. If you uncheck this, the popup will be shown always a user navigates to your website, regardless if he accepted or not cookies before. Use this feature only for testing purposes!";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_popup_once" name="fortune_Main_Settings[fortune_popup_once]" <?php
    if ($fortune_popup_once == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Enable Browser 'Do Not Track' Detection:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable browser 'do not track' signal detection? If you enabled this, a php variable will be available named: dntEnabled";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_dnt_check" name="fortune_Main_Settings[fortune_dnt_check]" <?php
    if ($fortune_dnt_check == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>Clear All Cookies From Your Domain (testing purpose):</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This button will clear all cookies that your website has inserted in your browsers cookie database. This feauture is useful for testing purposes, because clearing cookies only affects your local session (internet users will not notice this).";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="button" id="fortune_clear_all_cookies" value="Delete" name="fortune_clear_all_cookies" onclick="fortune_delete_cookies()">
                    <?php
                    if(isset($_COOKIE['fortune_show']) && $_COOKIE['fortune_show'] == '1')
                    {
                          echo "&nbsp;&nbsp;Cookie is SET.";
                    }
                    else
                    {
                          echo "&nbsp;&nbsp;Cookie is NOT SET.";
                    }
                    ?>  
                    </td></tr>
        </div>
        <tr><td><hr/></td><td><hr/></td></tr>
        <tr><td>
        <h3><b>Shortcode Settings:</b></h3></td></tr>
        <div>
                    <tr><td>
                    <b>Enable 'Blocked Content Placeholder' [fortune_blocked_no_cookies] Shortcode:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Enable blocked content placeholder shortcode - use it like this: [fortune_blocked_no_cookies]CONTENT YOU WANT TO SHOW ONLY TO USERS WHO ALREADY ACCEPTED COOKIES. THIS CAN BE ALSO HTML CODE.[/fortune_blocked_no_cookies]?";
?>
                        </div>
                    </div>
                    </td><td>
                    <input type="checkbox" id="fortune_blocked_content" name="fortune_Main_Settings[fortune_blocked_content]" onclick="centerChanged()" <?php
    if ($fortune_blocked_content == 'on')
        echo ' checked ';
?>>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <div class="loggedin_disable">
                    <b>Blocked Content Placeholder Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The placeholder text for the content that was blocked. This could be: 'This content requiers cookies to function properly. This will not be visible until you accept cookies.'";
?>
                        </div>
                    </div>
                    </div>
                    </td><td>
                    <div class="loggedin_disable">
                    <textarea rows="4" cols="44" name="fortune_Main_Settings[fortune_blocked_content_text]" ng-model="settings.fortune_blocked_content_text"></textarea>
                    </div>    
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The [get_cookies_opt_out_button] Shortcode Generated Button Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The text of the 'Delete Cookies' button generated by the [get_cookies_opt_out_button] shortcode.";
?>
                        </div>
                    </div>
                    </td><td>
                    <textarea rows="1" cols="44" name="fortune_Main_Settings[fortune_cookie_delete_text]" ng-model="settings.fortune_cookie_delete_text"></textarea>
                        
                    </td></tr>
        </div>
        <div>
                    <tr><td>
                    <b>The [get_cookies_opt_out_button] Shortcode Generated Button Delete Confirmation Text:</b>
                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "The confirmation message to be shown to the user that clicks on  the [get_cookies_opt_out_button] shortcode generated delete cookies button.";
?>
                        </div>
                    </div>
                    </td><td>
                    <textarea rows="2" cols="44" name="fortune_Main_Settings[fortune_cookie_accept_delete_text]" ng-model="settings.fortune_cookie_accept_delete_text"></textarea>
                        
                    </td></tr>
        </div>
        
                </table>
                <hr/>
<div>
<h3>Tips and Tricks:</h3>
<b>To stop cookies setting until the user has given permission, put your cookies setters inside this condition:</b>
    <pre>
&lt;?php if(isset($_COOKIE['fortune_show']) && $_COOKIE['fortune_show'] == '1')
{
    //place your cookie handler code here
}?&gt;
    </pre>
    <b>To check if browser set the 'Do Not Track' signal:</b>
    <pre>
&lt;?php if($GLOBALS['dntEnabled'] === true)
{
    //place your 'Do Not Track' Request handler code here
}?&gt;
    </pre>
    <b>And also, you can use any of these three shortcodes:</b><br/><br/>
    - The first one is [fortune_blocked_no_cookies] - this shortcode (if it is enabled from above settings), will block the content that it contains, and will display a placeholder text, until the users does not accept cookies
    <pre>
[fortune_blocked_no_cookies] 
THE COOL BLOCKED CONTENT WILL BE HERE
[/fortune_blocked_no_cookies]
    </pre>
    - The second one is [get_new_fortune_cookie] - this shortcode will display a random fortune cookie for your visitors! Enjoy it!
    <pre>
[get_new_fortune_cookie]
    </pre>
    - And the third one is [get_cookies_opt_out_button] - this shortcode will display a button to the user, which will delete the cookie that the 'Fortune Cookie Consent Policy' plugin set (so the popup will be shown again) - in case the user changed his mind about his cookie option.
    <pre>
[get_cookies_opt_out_button]
    </pre>
    </div>
    <hr/>
    <b><h3>A fortune cookie for you: </h3>&quot;<?php
    echo get_new_fortune_cookie();
?>&quot;</b><br/><hr/>
        </div>
        </div>
        
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    
    </form>
</div>
</div><?php
}
?>