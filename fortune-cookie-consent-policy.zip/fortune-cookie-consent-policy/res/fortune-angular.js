angular.module('forsettingsApp', ['ngSanitize'])
.controller('forsettingsController', function($scope) {
    $scope.settings = fortune_admin_json;
});