(function($) {
  "use strict" 
	$(document).ready(function() {
        function getCookie(cname) {
            var name = cname + "=";
            var ca = document.cookie.split(';');
            for(var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }
 
		var $doc = $(document)
          , $body = $('body')
          , $modal;
        if(settings.use_cookies === 'on')
        {
            var cook = getCookie("fortune_show");
            if (cook != "") 
            {
                return;
            }
        }
        var $toFade = "";
        $modal = "";
        $modal += '<style>.link_button {-webkit-border-radius: 4px;-moz-border-radius: 4px;border-radius: 4px;border: solid 1px ' + settings.button_border + ';text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.4);-webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.4), 0 1px 1px rgba(0, 0, 0, 0.2);-moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.4), 0 1px 1px rgba(0, 0, 0, 0.2);box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.4), 0 1px 1px rgba(0, 0, 0, 0.2);background: #4479BA;color: #FFF;padding: 8px 12px;text-decoration: none;}';
        if(settings.custom_css !== '' && settings.custom_css !== null)
        {
            $modal += settings.custom_css;
        }
        $modal += '</style><script>var myVar;</script>';
        if(settings.auto_hide === 'on')
        {
            if(settings.auto_accept === 'on')
            {
                $modal += '<script>myVar=setTimeout(function() { clickClose(); }, ' + settings.auto_hide_time + ')</script>';
            }
            else
            {
                $modal += '<script>myVar=setTimeout(function() { clickDeny(); }, ' + settings.auto_hide_time + ')</script>';
            }
        }
        $modal += "<script>function setCookie(cname, cvalue, exminutes) {";
        if(settings.block_all_cookies !== 'on' && settings.block_cookies === 'on')
        {
            $modal += "var originalCookie =  Object.getOwnPropertyDescriptor(Document.prototype, 'cookie') ||Object.getOwnPropertyDescriptor(HTMLDocument.prototype, 'cookie');if (originalCookie && originalCookie.configurable) {  Object.defineProperty(document, 'cookie', {get: function() {return originalCookie.get.call(document);},set: function(val) {originalCookie.set.call(document, val);}});}";
        }
        $modal += "var d = new Date();d.setTime(d.getTime() + (exminutes*60*1000));var expires = 'expires='+d.toUTCString();document.cookie = cname + '=' + cvalue + ';' + expires + ';path=/';}function clickClose(){setCookie('fortune_show', 1, " + settings.cookie_exp + ");"
        if(settings.fade_background === 'on')
        {
            $toFade = "#fortune-overlay";
        }
        else
        {
            $toFade = "#note";
        }
        if(settings.animation === 'fortune_no_anim')
        {
            $modal += 'jQuery("' + $toFade + '").hide();';
        }
        else{
            if(settings.animation === 'fortune_slide_anim')
            {
                $modal += 'jQuery("' + $toFade + '").slideUp();';
            }
            else
            {
                $modal += 'jQuery("' + $toFade + '").fadeOut();';
            }
        }
        $modal += '}function clickDeny(){';
        if(settings.fade_background === 'on')
        {
            $toFade = "#fortune-overlay";
        }
        else
        {
            $toFade = "#note";
        }
        
        if(settings.animation === 'fortune_no_anim')
        {
            $modal += 'jQuery("' + $toFade + '").hide();';
            if($toFade === "#fortune-overlay")
            {
                $modal += 'jQuery("#note").hide();';
            }
        }
        else
        {
            if(settings.animation === 'fortune_slide_anim')
            {
                $modal += 'jQuery("' + $toFade + '").slideUp();';
                if($toFade === "#fortune-overlay")
                {
                    $modal += 'jQuery("#note").slideUp();';
                }
            }
            else
            {
                $modal += 'jQuery("' + $toFade + '").fadeOut();';
                if($toFade === "#fortune-overlay")
                {
                    $modal += 'jQuery("#note").fadeOut();';
                }
            }
        }
        $modal += '}function cancelBubble(e) {var evt = e ? e:window.event;if (evt.stopPropagation)    evt.stopPropagation();if (evt.cancelBubble!=null) evt.cancelBubble = true;}</script>';
        if(settings.fade_background == 'on')
        {
            $modal += '<div class="fortune-overlay" id="fortune-overlay" style="z-index:9999999999;background: rgba(0,0,0,0.8)"';
            if(settings.outside_close === 'on')
            {
                if(settings.outside_accept === 'on')
                {
                    $modal += ' onclick="clickClose()"';
                }
                else
                {
                    $modal += ' onclick="clickDeny()"';
                }
            }
            $modal += '>';
        }
        $modal += '<div name="note" onclick="cancelBubble(event)" class="fortune_popup" id="note" style="';
        $modal += 'max-height:' + settings.max_height + ';';
        $modal += 'font-size:' + settings.font_size + ';';
        $modal += 'font-family:' + settings.font_type + ';';
        if(settings.stick === 'on')
        {
            $modal += 'position: fixed;';
        }
        else
        {
            $modal += 'position: absolute;';
        }
        if(settings.dist_top !== '')
        {
            $modal += 'top: '+ settings.dist_top + ';';
        }
        if(settings.dist_bot !== '')
        {
            $modal += 'bottom: '+ settings.dist_bot + ';';
        }
        if(settings.dist_left !== '')
        {
            $modal += 'left: '+ settings.dist_left + ';';
        }
        if(settings.dist_right !== '')
        {
            $modal += 'right: '+ settings.dist_right + ';';
        }
        if(settings.rounded_corners === 'on')
        {
            $modal += 'border-radius: 25px;';
        }
        $modal += 'height:auto;max-width: ' + settings.max_width + ';';
        if(settings.border === 'on')
        {
            $modal += 'border-style: solid;border-width: ' + settings.border_width + ';border-color: ' + settings.border_color + ';';
        }
        
        $modal += 'color: ' + settings.text_col + ';';
        if(settings.background_style === 'fortune_color')
        {
            $modal += 'background: '+ settings.background + ';';
        }
        if(settings.background_style === 'fortune_transparent')
        {
            $modal += 'background: transparent;';
        }
        if(settings.background_style === 'fortune_image' && settings.background_image !== '')
        {
            $modal += 'background: '+ settings.background + ';background-image: url(&quot;' + settings.background_image + '&quot;);background-size: 100% 100%;-webkit-background-size: 100% 100%;-moz-background-size: 100% 100%;-o-background-size: 100% 100%;';
        }
        if(settings.center_popup === 'on' && settings.dist_left === '50%' && settings.popup_style === 'fortune_popup')
        {
            $modal += 'transform: translate(-50%, 0);';
        }
        $modal += '">';
        $modal += '<p style="';
        if(settings.background_style === 'fortune_color')
        {
            $modal += 'background: '+ settings.background + ';';
        }
        if(settings.background_style === 'fortune_transparent')
        {
            $modal += 'background: transparent;';
        }
        if(settings.background_style === 'fortune_image' && settings.background_image !== '')
        {
            $modal += 'background: '+ settings.background + ';background-image: url(&quot;' + settings.background_image + '&quot;);background-size: 100% 100%;-webkit-background-size: 100% 100%;-moz-background-size: 100% 100%;-o-background-size: 100% 100%;';
        }
        $modal += 'font-size:' + settings.font_size + ';font-family:' + settings.font_type + ';color: ' + settings.text_col + ';margin: 0 0 0;';
        $modal += 'padding: ' + settings.dist_padding + '">';
        if(settings.font_bold === 'on')
        {
            $modal += '<b>';
        }
        if(settings.font_underline === 'on')
        {
            $modal += '<u>';
        }
        if(settings.font_italic === 'on')
        {
            $modal += '<i>';
        }
        $modal += settings.message;
        if(settings.font_italic === 'on')
        {
            $modal += '</i>';
        }
        if(settings.font_underline === 'on')
        {
            $modal += '</u>';
        }
        if(settings.font_bold === 'on')
        {
            $modal += '</b>';
        }
        if(settings.new_line === 'on')
        {
            $modal += '<br/>';
        }
        if(settings.more_info === 'on')
        {
            $modal += ' <a target="_blank" href="' + settings.more_link + '"';
            if(settings.buttons === 'on')
            {
                $modal += ' class="link_button" ';
            }
            $modal += 'style="white-space: nowrap';
            if(settings.buttons === 'on')
            {
                $modal += 'background: ' + settings.button_background + ';';
            }
            $modal += 'color: ' + settings.links_col + '">' + settings.more_info_text + '</a>';
        }
        if(settings.new_line === 'on' && settings.new_line_all === 'on')
        {
            $modal += '<br/>';
        }
        $modal += ' <a id="close" ';
        if(settings.buttons === 'on')
        {
            $modal += 'class="link_button" ';
        }
        $modal += 'style="white-space: nowrap';
        if(settings.buttons === 'on')
        {
            $modal += 'background: ' + settings.button_background + ';';
        }
        $modal += 'color: ' + settings.links_col + '" onclick="clearTimeout(myVar);clickClose()">' + settings.close_message + '</a>';
        if(settings.deny_button === 'on')
        {
            if(settings.new_line === 'on' && settings.new_line_all === 'on')
            {
                $modal += '<br/>';
            }
            $modal += ' <a id="deny" ';
            if(settings.buttons === 'on')
            {
                $modal += 'class="link_button" ';
            }
            $modal += 'style="white-space: nowrap';
            if(settings.buttons === 'on')
            {
                $modal += 'background: ' + settings.button_background + ';';
            }
            $modal += 'color: ' + settings.links_col + '" onclick="clearTimeout(myVar);clickDeny()">' + settings.deny_text + '</a>';
        }
        $modal += '</p></div>';
        if(settings.fade_background == 'on')
        {
            $modal += '</div>';
        }
        $body.append($modal);   
	});
})(jQuery);