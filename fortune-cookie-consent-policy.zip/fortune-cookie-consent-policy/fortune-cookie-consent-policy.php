<?php
/** 
Plugin Name: Fortune Cookie Consent Policy
Plugin URI: http://codecanyon.net/user/kisded/portfolio
Description: This plugin automatically displays a warning message to users about the site using cookies, so it will respect the EU Cookie Law. Bonus: Fortune Cookies!
Author: kisded
Version: 1.0
Author URI: https://codecanyon.net/user/kisded
*/
require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/fortune/master/info.json", __FILE__, "fortune-cookie-consent-policy");
add_action('admin_menu', 'fortune_register_my_custom_menu_page');
function fortune_register_my_custom_menu_page()
{
    add_menu_page('Fortune Cookie Consent Policy', 'Fortune Cookie Consent Policy', 'manage_options', 'fortune_admin_settings', 'fortune_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('fortune_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'fortune_admin_settings');
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'fortune_add_settings_link');
function fortune_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=fortune_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

add_shortcode("get_new_fortune_cookie", "get_new_fortune_cookie");

function get_new_fortune_cookie()
{
    global $fortune_allCookies;
    $cookieContent = $fortune_allCookies[rand(0, sizeof($fortune_allCookies) - 1)];
    return $cookieContent;
}

function fortune_blocked_no_cookies()
{
    $fortune_Main_Settings        = get_option('fortune_Main_Settings', false);
    $fortune_blocked_content_text = $fortune_Main_Settings['fortune_blocked_content_text'];
    return $fortune_blocked_content_text;
}

function fortune_blocked_cookies($atts, $content = null)
{
    return $content;
}

$COOKIE_SET = 'false';

function fortune_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
register_activation_hook(__FILE__, 'fortune_activation_callback');
function fortune_activation_callback()
{
    $fortune_Main_Settings = array(
        'fortune_enabled' => 'on',
        'fortune_popup_once' => 'on',
        'fortune_popup_style' => 'fortune_panel_top',
        'fortune_close_message' => 'Accept',
        'fortune_message' => 'This site uses cookies to deliver its services. By using this site, you agree to its use of cookies.',
        'fortune_more_info' => 'on',
        'fortune_more_link' => 'https://www.google.com/policies/technologies/cookies/',
        'fortune_popup_background' => '#aaaaaa',
        'fortune_popup_text_col' => '#3f4c52',
        'fortune_popup_links_col' => '#0000ff',
        'fortune_panel_sticks' => 'on',
        'fortune_more_link_text' => 'More Info',
        'fortune_auto_hide' => 'off',
        'fortune_auto_hide_time' => '5000',
        'fortune_border' => 'off',
        'fortune_border_color' => '#ff0000',
        'fortune_border_width' => '3px',
        'fortune_buttons' => 'on',
        'fortune_popup_animation' => 'fortune_fade_anim',
        'fortune_max_width' => '',
        'fade_background' => 'on',
        'fortune_only_eu' => 'off',
        'fortune_block_cookies' => 'off',
        'fortune_blocked_content' => 'on',
        'fortune_deny_button_text' => 'Deny',
        'fortune_deny_button' => 'off',
        'fortune_block_all_cookies' => 'off',
        'fortune_disable_loggedin' => 'off',
        'fortune_custom_css' => '',
        'fortune_rounded_corners' => 'on',
        'fortune_distance_right' => '0px',
        'fortune_distance_left' => '0px',
        'fortune_distance_bottom' => 'auto',
        'fortune_distance_top' => '0px',
        'fortune_padding' => '10px',
        'fortune_new_line' => 'off',
        'fortune_auto_accept' => 'off',
        'fortune_outside_close_accept' => 'on',
        'fortune_outside_close' => 'on',
        'fortune_center_popup' => 'on',
        'fortune_advanced_settings' => 'off',
        'fortune_new_line_all' => 'off',
        'fortune_popup_background_style' => 'fortune_color',
        'fortune_popup_background_image' => '',
        'fortune_max_height' => '',
        'fortune_font_size' => '14px',
        'fortune_font_type' => 'Helvetica, Arial, sans-serif',
        'fortune_button_background' => '#aaaaaa',
        'fortune_cookie_exp' => '1440',
        'fortune_button_border' => '#0000ff',
        'fortune_fonts_bold' => 'off',
        'fortune_fonts_italic' => 'off',
        'fortune_fonts_underline' => 'off'
    );
    if (!get_option('fortune_Main_Settings')) {
        add_option('fortune_Main_Settings', $fortune_Main_Settings);
    } else {
        delete_option('fortune_Main_Settings');
        add_option('fortune_Main_Settings', $fortune_Main_Settings);
    }
    
    if (!get_option('fortune_accepted')) {
        add_option('fortune_accepted', 'no');
    } else {
        delete_option('fortune_accepted');
        add_option('fortune_accepted', 'no');
    }
}

register_activation_hook(__FILE__, 'fortune_check_version');
function fortune_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.3';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

function fortune_load_admin_things()
{
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('wp_ajax_fortune_my_action', 'fortune_my_action_callback');
function fortune_my_action_callback()
{
    $past = time() - 3600;
    foreach ($_COOKIE as $key => $value) {
        setcookie($key, $value, $past, '/');
    }
    echo "0";
    die();
}

add_action('admin_enqueue_scripts', 'fortune_load_admin_things');

add_action('admin_init', 'fortune_register_mysettings');
function fortune_register_mysettings()
{
    register_setting('fortune_option_group', 'fortune_Main_Settings');
}

add_action('wp_footer', 'fortune_footer_content');
function fortune_footer_content()
{
?><script type="text/javascript">
        var $fortune_Main_Settings = JSON.parse('<?php
    echo json_encode($fortune_Main_Settings);
?>');
        </script><?php
}

function fortune_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function fortune_ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array(
        "name",
        "\n",
        "\t",
        " ",
        "-",
        "_"
    ), NULL, strtolower(trim($purpose)));
    $support    = array(
        "country",
        "countrycode",
        "state",
        "region",
        "city",
        "location",
        "address"
    );
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array(
                        $ipdat->geoplugin_countryName
                    );
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

function fortune_is_in_EU()
{
    $europe = array(
        'AD',
        'AL',
        'AT',
        'AX',
        'BA',
        'BE',
        'BG',
        'BY',
        'CH',
        'CZ',
        'DE',
        'DK',
        'EE',
        'ES',
        'FI',
        'FO',
        'FR',
        'GB',
        'GG',
        'GI',
        'GR',
        'HR',
        'HU',
        'IE',
        'IM',
        'IS',
        'IT',
        'JE',
        'LI',
        'LT',
        'LU',
        'LV',
        'MC',
        'MD',
        'ME',
        'MK',
        'MT',
        'NL',
        'NO',
        'PL',
        'PT',
        'RO',
        'RS',
        'RU',
        'SE',
        'SI',
        'SJ',
        'SK',
        'SM',
        'UA',
        'UK',
        'VA'
    );
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $real_ip_adress = $_SERVER['HTTP_CLIENT_IP'];
    } else {
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $real_ip_adress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $real_ip_adress = $_SERVER['REMOTE_ADDR'];
        }
    }
    
    $cip          = $real_ip_adress;
    $country_code = fortune_ip_info($real_ip_adress, "Country Code");
    if ($country_code === NULL) {
        return true;
    }
    if (in_array($country_code, $europe)) {
        return true;
    } else {
        return false;
    }
}

function fortune_get_file_url($url)
{
    return fortune_get_plugin_url() . '/' . $url;
}
add_action('template_redirect', 'fortune_add_browser_popup_panel');
function fortune_add_browser_popup_panel()
{
    $fortune_Main_Settings                      = get_option('fortune_Main_Settings', false);
    $fortune_Main_Settings['fortune_font_type'] = str_replace('"', "", $fortune_Main_Settings['fortune_font_type']);
    update_option('fortune_Main_Settings', $fortune_Main_Settings);
    $cookie_val = $_COOKIE['fortune_show'];
    if ($cookie_val === '1') {
        $GLOBALS['COOKIE_SET'] = 'true';
    }
    
    $fortune_Main_Settings          = get_option('fortune_Main_Settings', false);
    $fortune_popup_once             = $fortune_Main_Settings['fortune_popup_once'];
    $fortune_message                = $fortune_Main_Settings['fortune_message'];
    $fortune_close_message          = $fortune_Main_Settings['fortune_close_message'];
    $fortune_more_info              = $fortune_Main_Settings['fortune_more_info'];
    $fortune_more_link              = $fortune_Main_Settings['fortune_more_link'];
    $fortune_popup_background       = $fortune_Main_Settings['fortune_popup_background'];
    $fortune_popup_text_col         = $fortune_Main_Settings['fortune_popup_text_col'];
    $fortune_popup_links_col        = $fortune_Main_Settings['fortune_popup_links_col'];
    $fortune_panel_sticks           = $fortune_Main_Settings['fortune_panel_sticks'];
    $fortune_more_link_text         = $fortune_Main_Settings['fortune_more_link_text'];
    $fortune_auto_hide_time         = $fortune_Main_Settings['fortune_auto_hide_time'];
    $fortune_auto_hide              = $fortune_Main_Settings['fortune_auto_hide'];
    $fortune_border                 = $fortune_Main_Settings['fortune_border'];
    $fortune_border_color           = $fortune_Main_Settings['fortune_border_color'];
    $fortune_border_width           = $fortune_Main_Settings['fortune_border_width'];
    $fortune_buttons                = $fortune_Main_Settings['fortune_buttons'];
    $fortune_popup_animation        = $fortune_Main_Settings['fortune_popup_animation'];
    $fortune_max_width              = $fortune_Main_Settings['fortune_max_width'];
    $fortune_fade_background        = $fortune_Main_Settings['fortune_fade_background'];
    $fortune_only_eu                = $fortune_Main_Settings['fortune_only_eu'];
    $fortune_block_cookies          = $fortune_Main_Settings['fortune_block_cookies'];
    $fortune_blocked_content        = $fortune_Main_Settings['fortune_blocked_content'];
    $fortune_deny_button            = $fortune_Main_Settings['fortune_deny_button'];
    $fortune_deny_button_text       = $fortune_Main_Settings['fortune_deny_button_text'];
    $fortune_block_all_cookies      = $fortune_Main_Settings['fortune_block_all_cookies'];
    $fortune_disable_loggedin       = $fortune_Main_Settings['fortune_disable_loggedin'];
    $fortune_custom_css             = $fortune_Main_Settings['fortune_custom_css'];
    $fortune_rounded_corners        = $fortune_Main_Settings['fortune_rounded_corners'];
    $fortune_distance_top           = $fortune_Main_Settings['fortune_distance_top'];
    $fortune_distance_bottom        = $fortune_Main_Settings['fortune_distance_bottom'];
    $fortune_distance_left          = $fortune_Main_Settings['fortune_distance_left'];
    $fortune_distance_right         = $fortune_Main_Settings['fortune_distance_right'];
    $fortune_padding                = $fortune_Main_Settings['fortune_padding'];
    $fortune_new_line               = $fortune_Main_Settings['fortune_new_line'];
    $fortune_auto_accept            = $fortune_Main_Settings['fortune_auto_accept'];
    $fortune_outside_close_accept   = $fortune_Main_Settings['fortune_outside_close_accept'];
    $fortune_outside_close          = $fortune_Main_Settings['fortune_outside_close'];
    $fortune_center_popup           = $fortune_Main_Settings['fortune_center_popup'];
    $fortune_popup_style            = $fortune_Main_Settings['fortune_popup_style'];
    $fortune_new_line_all           = $fortune_Main_Settings['fortune_new_line_all'];
    $fortune_popup_background_style = $fortune_Main_Settings['fortune_popup_background_style'];
    $fortune_popup_background_image = $fortune_Main_Settings['fortune_popup_background_image'];
    $fortune_max_height             = $fortune_Main_Settings['fortune_max_height'];
    $fortune_font_size              = $fortune_Main_Settings['fortune_font_size'];
    $fortune_font_type              = $fortune_Main_Settings['fortune_font_type'];
    $fortune_button_background      = $fortune_Main_Settings['fortune_button_background'];
    $fortune_cookie_exp             = $fortune_Main_Settings['fortune_cookie_exp'];
    $fortune_button_border          = $fortune_Main_Settings['fortune_button_border'];
    $fortune_fonts_bold             = $fortune_Main_Settings['fortune_fonts_bold'];
    $fortune_fonts_italic           = $fortune_Main_Settings['fortune_fonts_italic'];
    $fortune_fonts_underline        = $fortune_Main_Settings['fortune_fonts_underline'];
    
    if ($fortune_blocked_content === 'on' && $GLOBALS['COOKIE_SET'] !== 'true') {
        add_shortcode("fortune_blocked_no_cookies", "fortune_blocked_no_cookies");
    } else {
        add_shortcode("fortune_blocked_no_cookies", "fortune_blocked_cookies");
    }
    if (isset($fortune_Main_Settings['fortune_enabled']) && $fortune_Main_Settings['fortune_enabled'] == 'on') {
        if ($fortune_disable_loggedin === 'on' && is_user_logged_in()) {
            return;
        }
        if ($fortune_only_eu === 'on' && fortune_is_in_EU() === false) {
            return;
        }
        if (($fortune_block_all_cookies === 'on' || ($fortune_block_cookies === 'on' && $GLOBALS['COOKIE_SET'] !== 'true')) && headers_sent() === FALSE) {
            $dirty = false;
            foreach (headers_list() as $header) {
                if ($dirty)
                    continue;
                if (preg_match('/Set-Cookie/', $header))
                    $dirty = true;
            }
            if ($dirty) {
                $phpversion = explode('.', phpversion());
                if ($phpversion[0] > 5 || ($phpversion[0] === 5 && $phpversion[1] >= 3)) {
                    header_remove('Set-Cookie'); // php 5.3
                } else {
                    header('Set-Cookie:'); // php 5.2
                }
            }
            wp_register_script('fortune_enque_no_kuki_script', fortune_get_file_url('res/no_cookies.js'), array(
                'jquery'
            ));
            wp_enqueue_script('fortune_enque_no_kuki_script');
        }
        wp_register_style('fortune_enque_style', fortune_get_file_url('styles/notification.css'), array(), '1.0.0', 'all');
        wp_enqueue_style('fortune_enque_style');
        wp_register_script('fortune_enque_script', fortune_get_file_url('res/notification.js'), array(
            'jquery'
        ));
        wp_enqueue_script('fortune_enque_script');
        $settings = array(
            'use_cookies' => $fortune_popup_once,
            'stick' => $fortune_panel_sticks,
            'message' => $fortune_message,
            'close_message' => $fortune_close_message,
            'more_info' => $fortune_more_info,
            'more_link' => $fortune_more_link,
            'background' => $fortune_popup_background,
            'text_col' => $fortune_popup_text_col,
            'links_col' => $fortune_popup_links_col,
            'more_info_text' => $fortune_more_link_text,
            'auto_hide' => $fortune_auto_hide,
            'auto_hide_time' => $fortune_auto_hide_time,
            'border' => $fortune_border,
            'border_color' => $fortune_border_color,
            'border_width' => $fortune_border_width,
            'buttons' => $fortune_buttons,
            'animation' => $fortune_popup_animation,
            'max_width' => $fortune_max_width,
            'fade_background' => $fortune_fade_background,
            'deny_button' => $fortune_deny_button,
            'deny_text' => $fortune_deny_button_text,
            'custom_css' => $fortune_custom_css,
            'rounded_corners' => $fortune_rounded_corners,
            'dist_top' => $fortune_distance_top,
            'dist_bot' => $fortune_distance_bottom,
            'dist_right' => $fortune_distance_right,
            'dist_left' => $fortune_distance_left,
            'dist_padding' => $fortune_padding,
            'new_line' => $fortune_new_line,
            'auto_accept' => $fortune_auto_accept,
            'outside_close' => $fortune_outside_close,
            'outside_accept' => $fortune_outside_close_accept,
            'block_all_cookies' => $fortune_block_all_cookies,
            'center_popup' => $fortune_center_popup,
            'popup_style' => $fortune_popup_style,
            'new_line_all' => $fortune_new_line_all,
            'background_style' => $fortune_popup_background_style,
            'background_image' => $fortune_popup_background_image,
            'max_height' => $fortune_max_height,
            'font_size' => $fortune_font_size,
            'font_type' => $fortune_font_type,
            'button_background' => $fortune_button_background,
            'cookie_exp' => $fortune_cookie_exp,
            'block_cookies' => $fortune_block_cookies,
            'button_border' => $fortune_button_border,
            'font_bold' => $fortune_fonts_bold,
            'font_italic' => $fortune_fonts_italic,
            'font_underline' => $fortune_fonts_underline
        );
        wp_localize_script('fortune_enque_script', 'settings', $settings);
    }
}

add_action('admin_enqueue_scripts', 'fortune_admin_load_files');
function fortune_admin_load_files()
{
    wp_register_style('fortune-browser-style', plugins_url('styles/fortune-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('fortune-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('fortune-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fortune-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fortune-settings-app', plugins_url('res/fortune-angular.js', __FILE__), array(), '1.0.0', true);
}

require(dirname(__FILE__) . "/res/fortune-main.php");
require(dirname(__FILE__) . "/res/fortune-cookie-store.php");
?>